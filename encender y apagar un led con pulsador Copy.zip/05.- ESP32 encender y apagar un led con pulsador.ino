#define LED_AMARILLO 18
#define LED_AZUL     19
#define LED_ROJO     21

#define FREC_PWM 5000
#define RES_PWM  8

void apagarLeds() {
  ledcWrite(LED_AMARILLO, 0);
  ledcWrite(LED_AZUL, 0);
  ledcWrite(LED_ROJO, 0);
}

void modo1() {
  for (int i = 0; i < 3; i++) {
    ledcWrite(LED_AMARILLO, 255); delay(200); apagarLeds();
    ledcWrite(LED_AZUL, 255);     delay(200); apagarLeds();
    ledcWrite(LED_ROJO, 255);     delay(200); apagarLeds();
  }
}

void modo2() {
  for (int i = 0; i < 4; i++) {
    ledcWrite(LED_AMARILLO, 255);
    ledcWrite(LED_AZUL, 255);
    ledcWrite(LED_ROJO, 255);
    delay(250);
    apagarLeds();
    delay(250);
  }
}

void procesarComando(char cmd) {
  switch (cmd) {
    case 'A': apagarLeds(); ledcWrite(LED_AMARILLO, (int)(255 * 0.30)); break;
    case 'B': apagarLeds(); ledcWrite(LED_AZUL, (int)(255 * 0.70)); break;
    case 'C': apagarLeds(); ledcWrite(LED_ROJO, 255); break;
    case 'D': modo1(); break;
    case 'E': modo2(); break;
  }
}

void setup() {
  Serial.begin(115200);

  ledcAttach(LED_AMARILLO, FREC_PWM, RES_PWM);
  ledcAttach(LED_AZUL, FREC_PWM, RES_PWM);
  ledcAttach(LED_ROJO, FREC_PWM, RES_PWM);

  apagarLeds();
  Serial.println("ESP32 Listo para recibir comandos Seriales (A, B, C, D, E)...");
}

void loop() {
  if (Serial.available() > 0) {
    char cmd = Serial.read();
    procesarComando(cmd);
  }
}